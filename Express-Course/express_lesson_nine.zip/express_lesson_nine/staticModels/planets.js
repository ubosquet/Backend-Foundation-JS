
module.exports.planet = [
    {
        name: 'Mercury',
        numberOfMoons: 0
      },
      {
        name: 'Venus',
        numberOfMoons: 0
      },
      {
        name: 'Earth',
        numberOfMoons: 1
      },
      {
        name: 'Mars',
        numberOfMoons: 2
      },
      {
        name: 'Jupiter',
        numberOfMoons: 53
      },
      {
        name: 'Saturn',
        numberOfMoons: 62
      },
      {
        name: 'Uranus',
        numberOfMoons: 27
      },
      {
        name: 'Neptune',
        numberOfMoons: 13
      }

];
